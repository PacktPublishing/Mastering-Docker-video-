Social Media Icons from https://github.com/paulrobertlloyd/socialmediaicons

Licensed under a Creative Commons Attribution-Share Alike 3.0 license
