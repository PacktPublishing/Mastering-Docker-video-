HandlebarsAssets::Config.options = {preventIndent: true}
