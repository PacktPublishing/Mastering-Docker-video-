Rails.application.config.secret_token = AppConfig.secret_token
